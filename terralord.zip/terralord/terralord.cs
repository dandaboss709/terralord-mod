using Terraria.ModLoader;

namespace terralord
{
	public class terralord : Mod
	{
	}
}